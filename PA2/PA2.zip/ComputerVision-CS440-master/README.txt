Open the program through python eg
python RockPaperScissors.py in the command line

To initiate the game, smoothly move your fist down, up, down, up, down, up, down


Close the program by pressing q
